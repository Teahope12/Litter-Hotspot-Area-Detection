import os
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import cv2
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.regularizers import l2
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.utils import class_weight

# Define constants
img_size = (224, 224)
batch_size = 32
model_path = 'hotspot_classifier.h5'

# Function to train the model
def train_model():
    # Data Augmentation with reduced transformation to prevent overfitting
    train_datagen = ImageDataGenerator(
        rescale=1.0/255,
        rotation_range=10,  
        width_shift_range=0.1,  
        height_shift_range=0.1,  
        horizontal_flip=True,  
        validation_split=0.2    
    )

    # Load training data
    train_data = train_datagen.flow_from_directory(
        'dataset/',  
        target_size=img_size,
        batch_size=batch_size,
        class_mode='binary',
        subset='training'
    )

    # Load validation data
    val_data = train_datagen.flow_from_directory(
        'dataset/',  
        target_size=img_size,
        batch_size=batch_size,
        class_mode='binary',
        subset='validation'
    )

    print("✅ Training images:", train_data.samples)
    print("✅ Validation images:", val_data.samples)

    # Check class distribution to detect imbalance
    class_counts = np.bincount(train_data.classes)
    print("📊 Class Distribution:", dict(enumerate(class_counts)))

    # Compute class weights to handle imbalance
    class_weights = class_weight.compute_class_weight(
        class_weight="balanced",
        classes=np.unique(train_data.classes),
        y=train_data.classes
    )
    class_weights = dict(enumerate(class_weights))
    print("📊 Class Weights:", class_weights)

    # Build CNN Model with Batch Normalization & Regularization
    model = Sequential([
        Conv2D(32, (3,3), activation='relu', input_shape=(224, 224, 3)),
        BatchNormalization(),
        MaxPooling2D(2,2),

        Conv2D(64, (3,3), activation='relu', kernel_regularizer=l2(0.01)),
        BatchNormalization(),
        MaxPooling2D(2,2),

        Conv2D(128, (3,3), activation='relu', kernel_regularizer=l2(0.01)),
        BatchNormalization(),
        MaxPooling2D(2,2),

        Flatten(),
        Dense(128, activation='relu', kernel_regularizer=l2(0.01)),
        Dropout(0.7),  # Increased dropout
        Dense(1, activation='sigmoid')
    ])

    # Compile the model
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

    # Print model summary
    model.summary()

    # Use Early Stopping to prevent overfitting
    early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

    # Train the model
    history = model.fit(
        train_data, 
        validation_data=val_data, 
        epochs=20, 
        class_weight=class_weights, 
        callbacks=[early_stopping]
    )

    # Check final accuracy
    print("Final Training Accuracy:", history.history['accuracy'][-1])
    print("Final Validation Accuracy:", history.history['val_accuracy'][-1])

    # Plot training vs validation accuracy and loss
    plot_metrics(history)

    # Save the trained model
    model.save(model_path)
    print("✅ Model saved successfully!")

# Function to plot accuracy & loss to detect overfitting
def plot_metrics(history):
    plt.figure(figsize=(12, 4))

    # Plot accuracy
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Train Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.title('Training vs Validation Accuracy')

    # Plot loss
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Train Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Training vs Validation Loss')

    plt.show()

# Train only if model does not exist
if not os.path.exists(model_path):
    print("🛠 Training model as no pre-trained model found...")
    train_model()
else:
    print("✅ Pre-trained model found. Loading...")

# Load the trained model for prediction
model = load_model(model_path)
print("✅ Model loaded successfully!")

# Function to adjust decision threshold for better predictions
def predict_image(img_path, threshold=0.7, temperature=2.5):
    if not os.path.exists(img_path):
        return "❌ Error: File not found!"
    
    img = cv2.imread(img_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  
    img = cv2.resize(img, (224, 224))  
    img = img / 255.0  
    img = np.expand_dims(img, axis=0)  

    logits = model.predict(img)  
    scaled_output = tf.nn.sigmoid(logits / temperature)  

    confidence = float(scaled_output[0][0])  

    print(f"🔍 Raw Prediction Value: {confidence}")  

    if confidence <= threshold:  # Change threshold from 0.5 to 0.6 or 0.7
        return f"✅ Hotspot with {confidence:.2f} confidence"
    else:
        return f"❌ Not a Hotspot with {1-confidence:.2f} confidence"

# Example usage
img_path = r'D:\Tiyasha\dataset\non_hotspot\06_02_0041.png'
print(predict_image(img_path, threshold=0.51))
