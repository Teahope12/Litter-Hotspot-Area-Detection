import os
import numpy as np
import tensorflow as tf
import cv2
from docx import Document  # For writing results to a Word file
from tensorflow.keras.models import load_model

# Load the trained model
model_path = 'hotspot_classifier.h5'
if not os.path.exists(model_path):
    raise FileNotFoundError("❌ Error: Model not found. Train the model first!")

model = load_model(model_path)
print("✅ Model loaded successfully!")

# Function to predict threshold for an image
def calculate_threshold(img_path, temperature=2.5):
    if not os.path.exists(img_path):
        return None, "❌ Error: File not found!"
    
    img = cv2.imread(img_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  
    img = cv2.resize(img, (224, 224))  
    img = img / 255.0  
    img = np.expand_dims(img, axis=0)  

    logits = model.predict(img)  
    scaled_output = tf.nn.sigmoid(logits / temperature)  
    confidence = float(scaled_output[0][0])  

    return confidence, f"🔍 Prediction Value: {confidence:.2f}"

# Function to process all images in a folder and save results to a Word file
def process_images_and_save(folder_path, output_file='threshold_resultssnonhotspot.docx'):
    if not os.path.exists(folder_path):
        print("❌ Error: Folder not found!")
        return
    
    doc = Document()
    doc.add_heading('Image Threshold Results', level=1)

    # Iterate through all images
    for file_name in os.listdir(folder_path):
        if file_name.endswith(('.jpg', '.png', '.jpeg')):  
            img_path = os.path.join(folder_path, file_name)
            confidence, message = calculate_threshold(img_path)

            # Print results to console
            print(f"{file_name}: {message}")

            # Save results to Word file
            doc.add_paragraph(f"{file_name}: {message}")

    # Save document
    doc.save(output_file)
    print(f"✅ Results saved to {output_file}")

# Example usage
image_folder = r'D:\Tiyasha\dataset\non_hotspot'  # Change to your dataset folder
process_images_and_save(image_folder)
